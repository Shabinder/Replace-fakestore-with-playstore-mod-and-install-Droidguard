# Replace fakestore with PLAY STORE and install droidguard.

This is a module to simple replace fakestore with playstore and install droidguard helper in **los microg forks**, as many prefer microg over gapps and for an easy life thgey just install los microg for **but los microg comes with fakestore and no droid guard helper which breaks safetnet and user cant use paid apps as yalp store/aurora store downloaded paid apps doesnt pass license verification**

for making users work easy i just made this module to do all **systemlessly** and making ** OTA's INSTALLABLE ** and this thing ota survivable.

** now we can install paid apps from playstore and can pass safetynet without any issue(add droidguard in magisk hide)**

### NOTE:
**In some cases if during safety net check droidguard stops then plz intall the apk as an update over installed app by extracting the  module zip in /system/priv-apps/droidguard **
** for updating playstore download fdroid and add this repo in it "    https://nanolx.org/fdroid/repo/?fingerprint=862ED9F13A3981432BF86FE93D14596B381D75BE83A1D616E2D44A12654AD015  " **
### NEED HELP OR REPORT ISSUES:
**WRITE TO @SHABINDER ON TELEGRAM**

###credits: 
**MARVIN FOR MICROG , NANOLX FOR MODDED PLAYSTORE , TECHNO SHAB(aka Shabinder) for this module.
  
